// =====================================================================
// LETTERA O: il beat di questa lettera
//
// la forma della lettera è il ritmo: griglia(suoni) fa suonare ogni pixel '#'
// con il suono della sua riga (16 righe, dall'alto in basso).
// qui puoi scrivere qualsiasi codice Strudel: altri suoni, effetti, velocità,
// altri strati con stack(...). L'ultima espressione è quella che suona.
// la pagina pensa da sola all'ingresso da destra, alla pausa e al reset.
// (attenzione: tra "doppie virgolette" Strudel legge la mini-notazione, es. "bd sd")
// =====================================================================

setcps(0.5)   // velocità: cicli al secondo (0.5 = di base)

const suoni = [
  'cr','rd','rd','oh',                      // ascendenti (righe 0-3)
  'hh','hh','rim','ht','cp','mt','sd','bd', // x-height (righe 4-11, la cassa sulla linea di base)
  'lt','lt','bd','bd',                      // discendenti (righe 12-15)
]

// esempio: suoni all'altezza originale (null), più un basso che segue le ripetizioni
stack(
  griglia(suoni, null).bank('RolandTR909'),
  note("c2 ~ eb2 ~").s('sawtooth').lpf(400).decay(.2).sustain(0),
)
